<section class="list_area_item">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/3.jpg" width="388" height="258" alt="Hakkımızda">
                    <h2 class="title">Hakkımızda</h2>   
                    <a href="#" title="Hakkımızda" class="hakkimizda_item"></a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/2.jpg" width="388" height="258" alt="Şubelerimiz">
                    <h2 class="title">Şubelerimiz</h2>   
                    <a href="#" title="Şubelerimiz" class="hakkimizda_item"></a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/1.jpg" width="388" height="258" alt="Blog">
                    <h2 class="title">Blog</h2>   
                    <a href="#" title="Blog" class="hakkimizda_item"></a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/4.jpg" width="388" height="258" alt="Sektörden Haberler">
                    <h2 class="title">Sektörden Haberler</h2>   
                    <a href="#" title="Sektörden Haberler" class="hakkimizda_item"></a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/5.jpg" width="388" height="258" alt="Kariyer">
                    <h2 class="title">Kariyer</h2>   
                    <a href="#" title="Kariyer" class="hakkimizda_item"></a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/6.jpg" width="388" height="258" alt="Hizmetlerimiz">
                    <h2 class="title">Hizmetlerimiz</h2>   
                    <a href="#" title="Hizmetlerimiz" class="hakkimizda_item"></a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/7.jpg" width="388" height="258" alt="Yasal Bilgiler">
                    <h2 class="title">Yasal Bilgiler</h2>   
                    <a href="#" title="Yasal Bilgiler" class="hakkimizda_item"></a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 clas_col">
                <div class="item">
                    <img src="assets/image/list_page/8.jpg" width="388" height="258" alt="Sosyal Sorumluluk Projelerimiz">
                    <h2 class="title">Sosyal Sorumluluk Projelerimiz</h2>   
                    <a href="#" title="Sosyal Sorumluluk Projelerimiz" class="hakkimizda_item"></a>
                </div>
            </div>
        </div>
    </div>
</section>