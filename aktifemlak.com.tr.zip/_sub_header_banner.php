<section class="header_banner" style="background-image:url('assets/image/header_banner/satilik_ilanlar.jpg');">
        <div class="text_area">
            <h1 class="h2">Kurumsal</h1>
            <ul class="breadcumb_ul">
                <li class="breadcumb_li">
                    <a href="index.php" title="Ana Sayfa">Ana Sayfa</a>
                </li>
                <li class="breadcumb_li">
                    <a href="satilik_ilanlar.php" title="Kurumsal">Kurumsal</a>
                </li>
            </ul>
            <ul class="share">
                <span class="s2">Paylaş</span>
                <li>
                    <a href="#" title="Kopyala">
                        <img src="assets/image/icons/chain.png" width="16" height="16" alt="">
                    </a>
                </li>
                <li>
                    <a href="#" title="Facebook">
                        <img src="assets/image/icons/face.png" width="16" height="16" alt="">
                    </a>
                </li>
                <li>
                    <a href="#" title="Twitter">
                        <img src="assets/image/icons/twit.png" width="20" height="16" alt="">
                    </a>
                </li>
                <li>
                    <a href="#" title="Linkedin">
                        <img src="assets/image/icons/linkedin.png" width="16" height="16" alt="">
                    </a>
                </li>
            </ul>
        </div>
</section>