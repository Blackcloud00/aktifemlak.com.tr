<section class="branches normal">
    <div class="container">
        <h2 class="index_title bold">Şubelerimizi Keşfet</h2>
        <div class="branch_list d-flex justify-content-xl-between justify-content-center">
            <div class="branch">
                <img src="assets/image/icons/building.png" width="49" height="44" alt="Şube Adı">
                <h6 class="bold">Şube Adı</h6>
                <span class="s2">Acente Temsilcisi: Bora TÜRKOĞLU</span>
                <span class="s2">Adres: Apt. 910 665 Lemke Loop, CO 06237-7979</span>
                <span class="s2">Telefon: 0 850 850 85 85</span>
                <a href="#" title="Şube Adı" class="branch_link"></a>
            </div>
            <div class="branch">
                <img src="assets/image/icons/building.png" width="49" height="44" alt="Şube Adı">
                <h6 class="bold">Şube Adı</h6>
                <span class="s2">Acente Temsilcisi: Bora TÜRKOĞLU</span>
                <span class="s2">Adres: Apt. 910 665 Lemke Loop, CO 06237-7979</span>
                <span class="s2">Telefon: 0 850 850 85 85</span>
                <a href="#" title="Şube Adı" class="branch_link"></a>
            </div>
            <div class="branch">
                <img src="assets/image/icons/building.png" width="49" height="44" alt="Şube Adı">
                <h6 class="bold">Şube Adı</h6>
                <span class="s2">Acente Temsilcisi: Bora TÜRKOĞLU</span>
                <span class="s2">Adres: Apt. 910 665 Lemke Loop, CO 06237-7979</span>
                <span class="s2">Telefon: 0 850 850 85 85</span>
                <a href="#" title="Şube Adı" class="branch_link"></a>
            </div>
            <div class="branch">
                <img src="assets/image/icons/building.png" width="49" height="44" alt="Şube Adı">
                <h6 class="bold">Şube Adı</h6>
                <span class="s2">Acente Temsilcisi: Bora TÜRKOĞLU</span>
                <span class="s2">Adres: Apt. 910 665 Lemke Loop, CO 06237-7979</span>
                <span class="s2">Telefon: 0 850 850 85 85</span>
                <a href="#" title="Şube Adı" class="branch_link"></a>
            </div>
            <div class="branch">
                <img src="assets/image/icons/building.png" width="49" height="44" alt="Şube Adı">
                <h6 class="bold">Şube Adı</h6>
                <span class="s2">Acente Temsilcisi: Bora TÜRKOĞLU</span>
                <span class="s2">Adres: Apt. 910 665 Lemke Loop, CO 06237-7979</span>
                <span class="s2">Telefon: 0 850 850 85 85</span>
                <a href="#" title="Şube Adı" class="branch_link"></a>
            </div>
        </div>
    </div>
</section>