<section class="detail_area_item">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 clas_col order-lg-0 order-1">
                <div class="text">
                    <h2>Lorem ipsum dolor sit amet consectetur.</h2>
                    <p>Lorem ipsum dolor sit amet consectetur. Nisi turpis non consectetur id morbi pulvinar mauris. Consequat at felis sit sagittis consectetur volutpat aliquet. Cras diam tellus pulvinar feugiat tincidunt porttitor arcu. Non pellentesque consectetur consequat fringilla urna sed eget lorem. Ut non enim eros blandit vitae magna vulputate sit. Vitae volutpat eu nisl mattis laoreet adipiscing habitasse. Volutpat hendrerit venenatis rutrum nam sed congue. Pulvinar id amet vestibulum est consectetur etiam. Ultrices dignissim quis nullam eget.</p>
                    <p>Ut massa fusce quam in. Sit vehicula arcu sit ut accumsan ac aliquam aenean. Lectus vivamus faucibus risus in in magna donec. Potenti sed nisi consectetur ultrices convallis nam. Ornare ultrices dignissim aenean dignissim nec eget. Aenean ut quis ac mus vitae nisl. Pharetra lacus nascetur ac eget egestas in nunc faucibus vulputate. Vitae ac feugiat amet dui.</p>
                    <p>Neque vulputate amet dolor risus morbi sed proin. Erat non et ullamcorper metus. Purus amet volutpat fames ullamcorper elit feugiat in. Sed odio ut in quisque integer odio purus. Ac augue praesent cras interdum tortor. Cursus lobortis vulputate justo quis tincidunt. Porttitor feugiat rhoncus non tempor. Urna elit urna in malesuada. Posuere integer vitae feugiat vivamus a tincidunt enim nisi tincidunt. </p>
                </div>
            </div>
            <div class="col-lg-3 order-lg-1 order-0">
                <img src="assets/image/list_page/default.jpg" class="default_img" width="388" height="258" alt="Hakkımızda">
            </div>
        </div>
    </div>
</section>