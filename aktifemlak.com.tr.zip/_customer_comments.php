<section class="customer_comments normal" style="background-image:url('assets/image/musteri_yorumlari/bg.jpg');">
    <div class="container">
        <h2 class="index_title bold">Müşteri Yorumları</h2>
        <div class="swiper customer_comments_slider">
            <div class="swiper-wrapper d-flex align-items-center">
                <div class="swiper-slide">
                    <div class="stars d-flex">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                    </div>
                    <div class="text text-center">
                        <p class="h5">Lorem ipsum dolor sit amet consectetur. Sodales curabitur justo nisl turpis egestas pharetra. Vestibulum ut ut consectetur commodo tempus. Dolor dictum ac mauris nisl. Maecenas porttitor viverra ipsum faucibus eu.</p>
                    </div>
                    <div class="profile_photo d-flex align-items-center flex-column">
                        <img src="assets/image/musteri_yorumlari/customer.jpg" width="120" height="120" alt="">
                        <h4 class="mt-2">Keanu Reeves</h4>
                        <h4 class="passive">CEO</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="stars d-flex">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                    </div>
                    <div class="text text-center">
                        <p class="h5">Lorem ipsum dolor sit amet consectetur. Sodales curabitur justo nisl turpis egestas pharetra. Vestibulum ut ut consectetur commodo tempus. Dolor dictum ac mauris nisl. Maecenas porttitor viverra ipsum faucibus eu.</p>
                    </div>
                    <div class="profile_photo d-flex align-items-center flex-column">
                        <img src="assets/image/musteri_yorumlari/customer.jpg" width="120" height="120" alt="">
                        <h4 class="mt-2">Keanu Reeves</h4>
                        <h4 class="passive">CEO</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="stars d-flex">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                    </div>
                    <div class="text text-center">
                        <p class="h5">Lorem ipsum dolor sit amet consectetur. Sodales curabitur justo nisl turpis egestas pharetra. Vestibulum ut ut consectetur commodo tempus. Dolor dictum ac mauris nisl. Maecenas porttitor viverra ipsum faucibus eu.</p>
                    </div>
                    <div class="profile_photo d-flex align-items-center flex-column">
                        <img src="assets/image/musteri_yorumlari/customer.jpg" width="120" height="120" alt="">
                        <h4 class="mt-2">Keanu Reeves</h4>
                        <h4 class="passive">CEO</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="stars d-flex">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                    </div>
                    <div class="text text-center">
                        <p class="h5">Lorem ipsum dolor sit amet consectetur. Sodales curabitur justo nisl turpis egestas pharetra. Vestibulum ut ut consectetur commodo tempus. Dolor dictum ac mauris nisl. Maecenas porttitor viverra ipsum faucibus eu.</p>
                    </div>
                    <div class="profile_photo d-flex align-items-center flex-column">
                        <img src="assets/image/musteri_yorumlari/customer.jpg" width="120" height="120" alt="">
                        <h4 class="mt-2">Keanu Reeves</h4>
                        <h4 class="passive">CEO</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="stars d-flex">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                        <img src="assets/image/icons/star.png" width="35" height="32" alt="Yıldız">
                    </div>
                    <div class="text text-center">
                        <p class="h5">Lorem ipsum dolor sit amet consectetur. Sodales curabitur justo nisl turpis egestas pharetra. Vestibulum ut ut consectetur commodo tempus. Dolor dictum ac mauris nisl. Maecenas porttitor viverra ipsum faucibus eu.</p>
                    </div>
                    <div class="profile_photo d-flex align-items-center flex-column">
                        <img src="assets/image/musteri_yorumlari/customer.jpg" width="120" height="120" alt="">
                        <h4 class="mt-2">Keanu Reeves</h4>
                        <h4 class="passive">CEO</h4>
                    </div>
                </div>
            </div>
            <div class="swiper-button-next">
                <img src="assets/image/icons/arrow_prev.png" alt="İleri">
            </div>
            <div class="swiper-button-prev">
                <img src="assets/image/icons/arrow-next.png" alt="İleri">
            </div>
        </div>
    </div>
</section>