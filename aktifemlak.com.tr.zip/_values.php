<section class="values normal d-xl-block d-none">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-md-6 item">
                <img src="assets/image/bilgi_alani/bilgi_alani_1.png" class="bg_images" width="524" height="207" alt="10 Yıllık Tecrübemizle Sektörün Zirvesindeyiz">
                <div class="text_item">
                    <h3 class="title s1">10 Yıllık Tecrübemizle Sektörün Zirvesindeyiz</h3>
                    <p class="s2">Aktif Emlak olarak, yıllardır sürdürdüğümüz lider konumumuzla, güvenilir ve yenilikçi hizmet anlayışımızla gayrimenkul sektöründe fark yaratıyoruz</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 item">
                <img src="assets/image/bilgi_alani/bilgi_alani_2.png" class="bg_images" width="524" height="207" alt="Müşteri Memnuniyeti Önceliğimizdir">
                <div class="text_item">
                    <h3 class="title s1">Müşteri Memnuniyeti Önceliğimizdir</h3>
                    <p class="s2">Müşterilerimize en iyi hizmeti sunmak için sürekli olarak çalışıyor, onların ihtiyaçlarını en iyi şekilde karşılamak için titizlikle hareket ediyoruz.</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 item">
                <img src="assets/image/bilgi_alani/bilgi_alani_3.png" class="bg_images" width="524" height="207" alt="Yenilikçi ve Kaliteli Hizmet Anlayışı">
                <div class="text_item">
                    <h3 class="title s1">Yenilikçi ve Kaliteli Hizmet Anlayışı</h3>
                    <p class="s2">Teknolojinin getirdiği yenilikleri hizmetlerimize entegre ederek, siz değerli müşterilerimize en modern ve kaliteli gayrimenkul hizmetlerini sunuyoruz.</p>
                </div>
            </div>
        </div>
    </div>
</section>