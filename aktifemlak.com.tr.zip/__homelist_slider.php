<div class="swiper one_cikanlar">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="img_uruns" style="background: linear-gradient(180deg, rgba(255, 255, 255, 0.00) 51.5%, #FFF 100%), url(assets/image/urunler/urun_img_1.jpg) lightgray 50% / cover no-repeat;">
                                <div class="d-flex list_btns">
                                    <span class="cat one_cikan">ÖNE ÇIKAN</span>
                                    <span class="cat">SATILIK</span>
                                    <span class="cat btns_cat d-flex">
                                        <a href="#" title="">
                                            <img src="assets/image/icons/svg_area.svg" width="20" height="20" alt="btn_area">
                                        </a>
                                        <a href="#" title="">
                                            <img src="assets/image/icons/hearth.svg" width="20" height="20" alt="btn_area"> 
                                        </a>
                                    </span>
                                </div>
                                <div class="d-flex list_btns locate">
                                    <span class="cat item_type">KONUT</span>
                                </div>
                            </div>
                            <div class="text_area">
                                <h2 class="title_area h3">Lorem ipsum dolor sit amet consectetur pellentesque.</h2>
                                <div class="d-flex adres_area">
                                    <img src="assets/image/icons/adres.png" width="24" height="24" alt="Lorem ipsum dolor sit amet consectetur pellentesque.">
                                    <span>Apt. 910 665 Lemke Loop, Hyofort, CO 06237-7979</span>
                                </div>
                                <div class="button_area d-flex">
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/oda.png" width="23" height="21" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/banyo.png" width="31" height="17" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/m2.png" width="28" height="25" alt="350m2">
                                        <span>350m2</span>
                                    </div>                                
                                </div>
                                <div class="price">
                                    <span>1.200.000₺</span>
                                </div>  
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_uruns" style="background: linear-gradient(180deg, rgba(255, 255, 255, 0.00) 51.5%, #FFF 100%), url(assets/image/urunler/urun_img_1.jpg) lightgray 50% / cover no-repeat;">
                                <div class="d-flex list_btns">
                                    <span class="cat one_cikan">ÖNE ÇIKAN</span>
                                    <span class="cat">SATILIK</span>
                                    <span class="cat btns_cat d-flex">
                                        <a href="#" title="">
                                            <img src="assets/image/icons/svg_area.svg" width="20" height="20" alt="btn_area">
                                        </a>
                                        <a href="#" title="">
                                            <img src="assets/image/icons/hearth.svg" width="20" height="20" alt="btn_area"> 
                                        </a>
                                    </span>
                                </div>
                                <div class="d-flex list_btns locate">
                                    <span class="cat item_type">KONUT</span>
                                </div>
                            </div>
                            <div class="text_area">
                                <h2 class="title_area h3">Lorem ipsum dolor sit amet consectetur pellentesque.</h2>
                                <div class="d-flex adres_area">
                                    <img src="assets/image/icons/adres.png" width="24" height="24" alt="Lorem ipsum dolor sit amet consectetur pellentesque.">
                                    <span>Apt. 910 665 Lemke Loop, Hyofort, CO 06237-7979</span>
                                </div>
                                <div class="button_area d-flex">
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/oda.png" width="23" height="21" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/banyo.png" width="31" height="17" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/m2.png" width="28" height="25" alt="350m2">
                                        <span>350m2</span>
                                    </div>                                
                                </div>
                                <div class="price">
                                    <span>1.200.000₺</span>
                                </div>  
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_uruns" style="background: linear-gradient(180deg, rgba(255, 255, 255, 0.00) 51.5%, #FFF 100%), url(assets/image/urunler/urun_img_1.jpg) lightgray 50% / cover no-repeat;">
                                <div class="d-flex list_btns">
                                    <span class="cat one_cikan">ÖNE ÇIKAN</span>
                                    <span class="cat">SATILIK</span>
                                    <span class="cat btns_cat d-flex">
                                        <a href="#" title="">
                                            <img src="assets/image/icons/svg_area.svg" width="20" height="20" alt="btn_area">
                                        </a>
                                        <a href="#" title="">
                                            <img src="assets/image/icons/hearth.svg" width="20" height="20" alt="btn_area"> 
                                        </a>
                                    </span>
                                </div>
                                <div class="d-flex list_btns locate">
                                    <span class="cat item_type">KONUT</span>
                                </div>
                            </div>
                            <div class="text_area">
                                <h2 class="title_area h3">Lorem ipsum dolor sit amet consectetur pellentesque.</h2>
                                <div class="d-flex adres_area">
                                    <img src="assets/image/icons/adres.png" width="24" height="24" alt="Lorem ipsum dolor sit amet consectetur pellentesque.">
                                    <span>Apt. 910 665 Lemke Loop, Hyofort, CO 06237-7979</span>
                                </div>
                                <div class="button_area d-flex">
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/oda.png" width="23" height="21" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/banyo.png" width="31" height="17" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/m2.png" width="28" height="25" alt="350m2">
                                        <span>350m2</span>
                                    </div>                                
                                </div>
                                <div class="price">
                                    <span>1.200.000₺</span>
                                </div>  
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_uruns" style="background: linear-gradient(180deg, rgba(255, 255, 255, 0.00) 51.5%, #FFF 100%), url(assets/image/urunler/urun_img_1.jpg) lightgray 50% / cover no-repeat;">
                                <div class="d-flex list_btns">
                                    <span class="cat one_cikan">ÖNE ÇIKAN</span>
                                    <span class="cat">SATILIK</span>
                                    <span class="cat btns_cat d-flex">
                                        <a href="#" title="">
                                            <img src="assets/image/icons/svg_area.svg" width="20" height="20" alt="btn_area">
                                        </a>
                                        <a href="#" title="">
                                            <img src="assets/image/icons/hearth.svg" width="20" height="20" alt="btn_area"> 
                                        </a>
                                    </span>
                                </div>
                                <div class="d-flex list_btns locate">
                                    <span class="cat item_type">KONUT</span>
                                </div>
                            </div>
                            <div class="text_area">
                                <h2 class="title_area h3">Lorem ipsum dolor sit amet consectetur pellentesque.</h2>
                                <div class="d-flex adres_area">
                                    <img src="assets/image/icons/adres.png" width="24" height="24" alt="Lorem ipsum dolor sit amet consectetur pellentesque.">
                                    <span>Apt. 910 665 Lemke Loop, Hyofort, CO 06237-7979</span>
                                </div>
                                <div class="button_area d-flex">
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/oda.png" width="23" height="21" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/banyo.png" width="31" height="17" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/m2.png" width="28" height="25" alt="350m2">
                                        <span>350m2</span>
                                    </div>                                
                                </div>
                                <div class="price">
                                    <span>1.200.000₺</span>
                                </div>  
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_uruns" style="background: linear-gradient(180deg, rgba(255, 255, 255, 0.00) 51.5%, #FFF 100%), url(assets/image/urunler/urun_img_1.jpg) lightgray 50% / cover no-repeat;">
                                <div class="d-flex list_btns">
                                    <span class="cat one_cikan">ÖNE ÇIKAN</span>
                                    <span class="cat">SATILIK</span>
                                    <span class="cat btns_cat d-flex">
                                        <a href="#" title="">
                                            <img src="assets/image/icons/svg_area.svg" width="20" height="20" alt="btn_area">
                                        </a>
                                        <a href="#" title="">
                                            <img src="assets/image/icons/hearth.svg" width="20" height="20" alt="btn_area"> 
                                        </a>
                                    </span>
                                </div>
                                <div class="d-flex list_btns locate">
                                    <span class="cat item_type">KONUT</span>
                                </div>
                            </div>
                            <div class="text_area">
                                <h2 class="title_area h3">Lorem ipsum dolor sit amet consectetur pellentesque.</h2>
                                <div class="d-flex adres_area">
                                    <img src="assets/image/icons/adres.png" width="24" height="24" alt="Lorem ipsum dolor sit amet consectetur pellentesque.">
                                    <span>Apt. 910 665 Lemke Loop, Hyofort, CO 06237-7979</span>
                                </div>
                                <div class="button_area d-flex">
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/oda.png" width="23" height="21" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/banyo.png" width="31" height="17" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/m2.png" width="28" height="25" alt="350m2">
                                        <span>350m2</span>
                                    </div>                                
                                </div>
                                <div class="price">
                                    <span>1.200.000₺</span>
                                </div>  
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_uruns" style="background: linear-gradient(180deg, rgba(255, 255, 255, 0.00) 51.5%, #FFF 100%), url(assets/image/urunler/urun_img_1.jpg) lightgray 50% / cover no-repeat;">
                                <div class="d-flex list_btns">
                                    <span class="cat one_cikan">ÖNE ÇIKAN</span>
                                    <span class="cat">SATILIK</span>
                                    <span class="cat btns_cat d-flex">
                                        <a href="#" title="">
                                            <img src="assets/image/icons/svg_area.svg" width="20" height="20" alt="btn_area">
                                        </a>
                                        <a href="#" title="">
                                            <img src="assets/image/icons/hearth.svg" width="20" height="20" alt="btn_area"> 
                                        </a>
                                    </span>
                                </div>
                                <div class="d-flex list_btns locate">
                                    <span class="cat item_type">KONUT</span>
                                </div>
                            </div>
                            <div class="text_area">
                                <h2 class="title_area h3">Lorem ipsum dolor sit amet consectetur pellentesque.</h2>
                                <div class="d-flex adres_area">
                                    <img src="assets/image/icons/adres.png" width="24" height="24" alt="Lorem ipsum dolor sit amet consectetur pellentesque.">
                                    <span>Apt. 910 665 Lemke Loop, Hyofort, CO 06237-7979</span>
                                </div>
                                <div class="button_area d-flex">
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/oda.png" width="23" height="21" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/banyo.png" width="31" height="17" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/m2.png" width="28" height="25" alt="350m2">
                                        <span>350m2</span>
                                    </div>                                
                                </div>
                                <div class="price">
                                    <span>1.200.000₺</span>
                                </div>  
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_uruns" style="background: linear-gradient(180deg, rgba(255, 255, 255, 0.00) 51.5%, #FFF 100%), url(assets/image/urunler/urun_img_1.jpg) lightgray 50% / cover no-repeat;">
                                <div class="d-flex list_btns">
                                    <span class="cat one_cikan">ÖNE ÇIKAN</span>
                                    <span class="cat">SATILIK</span>
                                    <span class="cat btns_cat d-flex">
                                        <a href="#" title="">
                                            <img src="assets/image/icons/svg_area.svg" width="20" height="20" alt="btn_area">
                                        </a>
                                        <a href="#" title="">
                                            <img src="assets/image/icons/hearth.svg" width="20" height="20" alt="btn_area"> 
                                        </a>
                                    </span>
                                </div>
                                <div class="d-flex list_btns locate">
                                    <span class="cat item_type">KONUT</span>
                                </div>
                            </div>
                            <div class="text_area">
                                <h2 class="title_area h3">Lorem ipsum dolor sit amet consectetur pellentesque.</h2>
                                <div class="d-flex adres_area">
                                    <img src="assets/image/icons/adres.png" width="24" height="24" alt="Lorem ipsum dolor sit amet consectetur pellentesque.">
                                    <span>Apt. 910 665 Lemke Loop, Hyofort, CO 06237-7979</span>
                                </div>
                                <div class="button_area d-flex">
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/oda.png" width="23" height="21" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/banyo.png" width="31" height="17" alt="3+1">
                                        <span>3+1</span>
                                    </div>
                                    <div class="d-flex mx-2">
                                        <img src="assets/image/icons/m2.png" width="28" height="25" alt="350m2">
                                        <span>350m2</span>
                                    </div>                                
                                </div>
                                <div class="price">
                                    <span>1.200.000₺</span>
                                </div>  
                            </div>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
</div>